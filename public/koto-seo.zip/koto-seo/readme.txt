=== Koto SEO ===
Contributors: kotoseo
Tags: seo, analytics, rank tracking, agency
Requires at least: 5.6
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Connect WordPress to Koto Agency Platform for SEO sync, rank tracking, and automated reporting.

== Description ==
Koto SEO connects your WordPress site to the Koto Agency Platform, enabling:
* Real-time SEO data sync to your agency dashboard
* Automated rank tracking and reporting
* Site health monitoring
* Search engine ping on content publish

== Installation ==
1. Upload the plugin folder to /wp-content/plugins/
2. Activate through the Plugins menu
3. Go to Koto SEO → Agency Connect
4. Paste your API token from Koto → SEO Hub → WP Sites

== Changelog ==
= 1.0.0 =
* Initial release
