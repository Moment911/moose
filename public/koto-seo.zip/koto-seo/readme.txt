=== Koto SEO ===
Contributors: hellokoto
Tags: seo, agency, rank tracking, page generation, koto
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.0
Stable tag: 2.0.0
License: GPLv2 or later

Connect your WordPress site to the Koto Agency Platform.

== Description ==

Koto SEO connects your WordPress site to the Koto Agency Platform, enabling:

* **Agency Test Endpoint** — connection verification with full site diagnostics
* **Page Sync** — sync all published pages and their SEO metadata to Koto
* **Batch Page Generation** — create city/location landing pages from Koto dashboard
* **Blog Generation** — publish AI-written blog posts directly to WordPress
* **Sitemap Rebuild** — trigger Yoast/Rank Math sitemap rebuild + ping Google & Bing
* **Automation** — run SEO automation sequences on demand
* **Auto-ping** — notifies Koto when you publish new content

Compatible with Yoast SEO and Rank Math. Works with any WordPress theme.

== Installation ==

1. Upload the `koto-seo` folder to `/wp-content/plugins/`
2. Activate the plugin in WordPress Admin → Plugins
3. Go to Koto SEO → Settings
4. Paste your API key from Koto Dashboard → Settings → API Keys
5. Click Save & Connect

== REST API Endpoints ==

All endpoints at `/wp-json/koto/v1/` — authenticated via `Authorization: Bearer {key}` or `X-KOTO-Key` header.

* `GET  /agency/test` — site info + connection test
* `GET  /pages` — all published pages with SEO data
* `POST /generate/batch` — create landing pages
* `GET  /gsc/overview` — GSC data if available
* `POST /blog/generate` — publish blog posts
* `POST /automation/run-now` — run automation
* `POST /sitemap/rebuild` — rebuild sitemap + ping engines
* `GET  /rankings` — ranking data placeholder

Legacy `hlseo/v1` namespace also supported for backwards compatibility.

== Changelog ==

= 2.0.0 =
* Complete rebuild — all endpoints required by Koto WP Control Center
* Added: /agency/test, /pages, /generate/batch, /gsc/overview, /blog/generate, /automation/run-now, /rankings
* Added: backward-compatible hlseo/v1 namespace
* Added: client_id linking to Koto client record
* Added: Rank Math support alongside Yoast SEO
* Added: auto-ping on post publish
* Added: Settings page with endpoint reference
* Added: Koto branding throughout admin UI
* Improved: Auth accepts both Authorization Bearer and X-KOTO-Key headers

= 1.0.0 =
* Initial release
