<?php
/**
 * Plugin Name: Koto SEO
 * Plugin URI: https://hellokoto.com
 * Description: Connect your WordPress site to Koto Agency Platform for SEO sync, rank tracking, and automated reporting.
 * Version: 1.0.0
 * Author: Koto
 * Author URI: https://hellokoto.com
 * License: GPL-2.0+
 * Text Domain: koto-seo
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'KOTO_SEO_VERSION', '1.0.0' );
define( 'KOTO_SEO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'KOTO_SEO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// ── Admin menu ────────────────────────────────────────────────────────────────
add_action( 'admin_menu', function() {
    add_menu_page(
        'Koto SEO',
        'Koto SEO',
        'manage_options',
        'koto-seo',
        'koto_seo_admin_page',
        'dashicons-chart-area',
        100
    );
    add_submenu_page( 'koto-seo', 'Agency Connect', 'Agency Connect', 'manage_options', 'koto-seo-connect', 'koto_seo_connect_page' );
    add_submenu_page( 'koto-seo', 'Status',         'Status',         'manage_options', 'koto-seo-status',  'koto_seo_status_page'  );
} );

// ── Settings ─────────────────────────────────────────────────────────────────
add_action( 'admin_init', function() {
    register_setting( 'koto_seo_settings', 'koto_seo_api_key' );
    register_setting( 'koto_seo_settings', 'koto_seo_agency_url' );
    register_setting( 'koto_seo_settings', 'koto_seo_site_id' );
} );

// ── Admin pages ───────────────────────────────────────────────────────────────
function koto_seo_admin_page() { ?>
<div class="wrap">
  <h1>Koto SEO</h1>
  <div style="background:#fff;padding:24px;border-radius:8px;border:1px solid #e0e0e0;max-width:640px;">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">
      <div style="width:40px;height:40px;background:#ea2729;border-radius:8px;display:flex;align-items:center;justify-content:center;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
      </div>
      <div><h2 style="margin:0;">Koto SEO Plugin</h2><p style="margin:0;color:#666;">v<?php echo KOTO_SEO_VERSION; ?></p></div>
    </div>

    <?php $api_key = get_option('koto_seo_api_key'); $agency_url = get_option('koto_seo_agency_url'); ?>
    <?php if ($api_key && $agency_url): ?>
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:16px;margin-bottom:16px;">
        <strong style="color:#16a34a;">✓ Connected to Koto Agency Platform</strong><br>
        <span style="color:#6b7280;font-size:13px;"><?php echo esc_html($agency_url); ?></span>
      </div>
    <?php else: ?>
      <div style="background:#fef3c7;border:1px solid #fde68a;border-radius:8px;padding:16px;margin-bottom:16px;">
        <strong>Not connected yet.</strong> Go to <a href="<?php echo admin_url('admin.php?page=koto-seo-connect'); ?>">Agency Connect</a> to link this site to your Koto account.
      </div>
    <?php endif; ?>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
      <a href="<?php echo admin_url('admin.php?page=koto-seo-connect'); ?>" class="button button-primary" style="text-align:center;">Agency Connect</a>
      <a href="<?php echo admin_url('admin.php?page=koto-seo-status'); ?>" class="button" style="text-align:center;">View Status</a>
    </div>
  </div>
</div>
<?php }

function koto_seo_connect_page() {
    if ( isset($_POST['koto_save']) && check_admin_referer('koto_seo_connect') ) {
        update_option( 'koto_seo_api_key',   sanitize_text_field( $_POST['api_key'] ) );
        update_option( 'koto_seo_agency_url', esc_url_raw( $_POST['agency_url'] ) );
        // Register this site with Koto
        $response = koto_seo_register_site();
        if ( is_wp_error($response) ) {
            echo '<div class="notice notice-error"><p>Connection failed: ' . esc_html($response->get_error_message()) . '</p></div>';
        } else {
            update_option('koto_seo_site_id', $response['site_id'] ?? '');
            echo '<div class="notice notice-success"><p>✓ Connected to Koto successfully!</p></div>';
        }
    }
    $api_key    = get_option('koto_seo_api_key', '');
    $agency_url = get_option('koto_seo_agency_url', '');
    ?>
<div class="wrap">
  <h1>Agency Connect</h1>
  <div style="background:#fff;padding:24px;border-radius:8px;border:1px solid #e0e0e0;max-width:520px;">
    <p style="color:#374151;margin-bottom:20px;">Paste the API token from your Koto Agency Dashboard → SEO Hub → WP Sites.</p>
    <form method="post">
      <?php wp_nonce_field('koto_seo_connect'); ?>
      <table class="form-table">
        <tr>
          <th><label for="agency_url">Koto Agency URL</label></th>
          <td><input type="url" id="agency_url" name="agency_url" value="<?php echo esc_attr($agency_url); ?>" class="regular-text" placeholder="https://hellokoto.com" /></td>
        </tr>
        <tr>
          <th><label for="api_key">API Token</label></th>
          <td>
            <input type="password" id="api_key" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text" />
            <p class="description">Find this in Koto → SEO Hub → WP Sites → your site's API TOKEN</p>
          </td>
        </tr>
      </table>
      <p><input type="submit" name="koto_save" class="button button-primary" value="Connect Site" /></p>
    </form>
  </div>
</div>
<?php }

function koto_seo_status_page() {
    $api_key    = get_option('koto_seo_api_key');
    $agency_url = get_option('koto_seo_agency_url');
    $last_sync  = get_option('koto_seo_last_sync', 'Never');
    $site_info  = get_option('koto_seo_site_info', []);
    ?>
<div class="wrap">
  <h1>Koto SEO Status</h1>
  <div style="background:#fff;padding:24px;border-radius:8px;border:1px solid #e0e0e0;max-width:520px;">
    <table class="widefat" style="border:none;">
      <tr><th>Connection</th><td><?php echo $api_key ? '<span style="color:#16a34a;">✓ Connected</span>' : '<span style="color:#dc2626;">Not connected</span>'; ?></td></tr>
      <tr><th>Agency URL</th><td><?php echo esc_html($agency_url ?: '—'); ?></td></tr>
      <tr><th>Site URL</th><td><?php echo esc_html(get_site_url()); ?></td></tr>
      <tr><th>WordPress version</th><td><?php echo esc_html(get_bloginfo('version')); ?></td></tr>
      <tr><th>PHP version</th><td><?php echo esc_html(PHP_VERSION); ?></td></tr>
      <tr><th>Last sync</th><td><?php echo esc_html($last_sync); ?></td></tr>
      <tr><th>Plugin version</th><td><?php echo KOTO_SEO_VERSION; ?></td></tr>
    </table>
    <?php if ($api_key): ?>
    <p style="margin-top:16px;"><a href="<?php echo wp_nonce_url(admin_url('admin.php?page=koto-seo-status&action=sync'), 'koto_sync'); ?>" class="button button-primary">Sync Now</a></p>
    <?php endif; ?>
  </div>
</div>
<?php }

// ── Site registration ─────────────────────────────────────────────────────────
function koto_seo_register_site() {
    $api_key    = get_option('koto_seo_api_key');
    $agency_url = get_option('koto_seo_agency_url', 'https://hellokoto.com');
    $response   = wp_remote_post( trailingslashit($agency_url) . 'api/seo/wp-register', [
        'headers' => [ 'Content-Type' => 'application/json', 'X-Koto-Key' => $api_key ],
        'body'    => wp_json_encode([
            'site_url'    => get_site_url(),
            'site_name'   => get_bloginfo('name'),
            'wp_version'  => get_bloginfo('version'),
            'php_version' => PHP_VERSION,
            'api_key'     => $api_key,
        ]),
        'timeout' => 15,
    ]);
    if ( is_wp_error($response) ) return $response;
    $body = json_decode( wp_remote_retrieve_body($response), true );
    return $body ?: new WP_Error('parse_error', 'Invalid response from Koto');
}

// ── REST API endpoints ────────────────────────────────────────────────────────
add_action( 'rest_api_init', function() {
    $ns = 'hlseo/v1';  // Keep namespace for backwards compat

    // Site info
    register_rest_route( $ns, '/site/info', [
        'methods'             => 'GET',
        'callback'            => 'koto_seo_rest_site_info',
        'permission_callback' => 'koto_seo_auth',
    ]);

    // Stats
    register_rest_route( $ns, '/stats', [
        'methods'             => 'GET',
        'callback'            => 'koto_seo_rest_stats',
        'permission_callback' => 'koto_seo_auth',
    ]);

    // Sitemap rebuild
    register_rest_route( $ns, '/sitemap/rebuild', [
        'methods'             => 'POST',
        'callback'            => 'koto_seo_rest_sitemap_rebuild',
        'permission_callback' => 'koto_seo_auth',
    ]);

    // Ping search engines
    register_rest_route( $ns, '/ping/search-engines', [
        'methods'             => 'POST',
        'callback'            => 'koto_seo_rest_ping',
        'permission_callback' => 'koto_seo_auth',
    ]);

    // Generate recommendations
    register_rest_route( $ns, '/recommendations/generate', [
        'methods'             => 'POST',
        'callback'            => 'koto_seo_rest_recommendations',
        'permission_callback' => 'koto_seo_auth',
    ]);
});

// ── Auth middleware ───────────────────────────────────────────────────────────
function koto_seo_auth( WP_REST_Request $request ) {
    $stored_key = get_option('koto_seo_api_key');
    if ( ! $stored_key ) return new WP_Error('no_key', 'Plugin not configured', [ 'status' => 401 ]);
    $provided = $request->get_header('X-HLSEO-Key') ?: $request->get_header('Authorization');
    $provided = str_replace('Bearer ', '', $provided ?? '');
    return hash_equals( $stored_key, $provided )
        ? true
        : new WP_Error('unauthorized', 'Invalid API key', [ 'status' => 401 ]);
}

// ── REST callbacks ────────────────────────────────────────────────────────────
function koto_seo_rest_site_info() {
    global $wpdb;
    $post_count = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status='publish' AND post_type='post'");
    $page_count = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status='publish' AND post_type='page'");
    return rest_ensure_response([
        'site_url'      => get_site_url(),
        'site_name'     => get_bloginfo('name'),
        'tagline'       => get_bloginfo('description'),
        'wp_version'    => get_bloginfo('version'),
        'php_version'   => PHP_VERSION,
        'post_count'    => (int) $post_count,
        'page_count'    => (int) $page_count,
        'plugin_version'=> KOTO_SEO_VERSION,
        'last_sync'     => get_option('koto_seo_last_sync', null),
        'active_plugins'=> array_values(array_map('dirname', get_option('active_plugins', []))),
        'theme'         => get_template(),
    ]);
}

function koto_seo_rest_stats() {
    $info = koto_seo_rest_site_info()->get_data();
    update_option('koto_seo_last_sync', current_time('mysql'));
    return rest_ensure_response( array_merge( $info, [
        'synced_at' => current_time('c'),
    ]));
}

function koto_seo_rest_sitemap_rebuild() {
    // Ping Yoast/Rank Math/etc sitemap if available
    $pinged = false;
    if ( function_exists('wpseo_get_value') || defined('WPSEO_VERSION') ) {
        do_action('wpseo_rebuild_sitemap', true);
        $pinged = true;
    }
    return rest_ensure_response([ 'success' => true, 'method' => $pinged ? 'yoast' : 'native', 'time' => current_time('c') ]);
}

function koto_seo_rest_ping() {
    $site = get_site_url();
    $sitemap = $site . '/sitemap.xml';
    $engines = [
        'google' => 'https://www.google.com/ping?sitemap=' . urlencode($sitemap),
        'bing'   => 'https://www.bing.com/ping?sitemap='   . urlencode($sitemap),
    ];
    $results = [];
    foreach ( $engines as $name => $url ) {
        $r = wp_remote_get($url, ['timeout'=>10]);
        $results[$name] = is_wp_error($r) ? 'error' : wp_remote_retrieve_response_code($r);
    }
    return rest_ensure_response([ 'success' => true, 'results' => $results, 'sitemap' => $sitemap ]);
}

function koto_seo_rest_recommendations() {
    global $wpdb;
    $recs = [];

    // Check posts without meta descriptions
    $no_meta = $wpdb->get_var(
        "SELECT COUNT(*) FROM $wpdb->posts p
         LEFT JOIN $wpdb->postmeta pm ON p.ID=pm.post_id AND pm.meta_key='_yoast_wpseo_metadesc'
         WHERE p.post_status='publish' AND p.post_type='post' AND (pm.meta_value IS NULL OR pm.meta_value='')"
    );
    if ((int)$no_meta > 0) {
        $recs[] = [ 'type'=>'meta_description', 'priority'=>'high', 'count'=>(int)$no_meta, 'message'=>"$no_meta posts missing meta descriptions — add them to improve CTR in search results." ];
    }

    // Check for pages without H1
    $recs[] = [ 'type'=>'site_health', 'priority'=>'medium', 'message'=>'Run a crawl from Koto SEO Hub to identify technical issues.' ];

    return rest_ensure_response([ 'success'=>true, 'recommendations'=>$recs, 'generated_at'=>current_time('c') ]);
}

// ── Auto-sync on post publish ─────────────────────────────────────────────────
add_action( 'publish_post', function( $post_id ) {
    $api_key    = get_option('koto_seo_api_key');
    $agency_url = get_option('koto_seo_agency_url');
    if ( ! $api_key || ! $agency_url ) return;
    wp_remote_post( trailingslashit($agency_url) . 'api/seo/wp-ping', [
        'headers' => [ 'Content-Type'=>'application/json', 'X-Koto-Key'=>$api_key ],
        'body'    => wp_json_encode([ 'event'=>'post_published', 'post_id'=>$post_id, 'site_url'=>get_site_url() ]),
        'timeout' => 5, 'blocking' => false,
    ]);
}, 10, 1 );
