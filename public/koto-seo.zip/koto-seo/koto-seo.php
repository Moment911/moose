<?php
/**
 * Plugin Name: Koto SEO
 * Plugin URI:  https://hellokoto.com
 * Description: Connect your WordPress site to the Koto Agency Platform. Enables rank tracking, page generation, GSC sync, sitemap management, and automated SEO reporting directly from your agency dashboard.
 * Version:     2.0.0
 * Author:      Koto
 * Author URI:  https://hellokoto.com
 * License:     GPL-2.0+
 * Text Domain: koto-seo
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'KOTO_VERSION',    '2.0.0' );
define( 'KOTO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'KOTO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'KOTO_NS',         'koto/v1' );     // /wp-json/koto/v1/...

// ── Admin menu ────────────────────────────────────────────────────────────────
add_action( 'admin_menu', function() {
    add_menu_page( 'Koto', 'Koto SEO', 'manage_options', 'koto-seo',
        'koto_page_dashboard', 'dashicons-chart-area', 100 );
    add_submenu_page( 'koto-seo', 'Connect',  'Connect',  'manage_options', 'koto-seo',        'koto_page_dashboard' );
    add_submenu_page( 'koto-seo', 'Status',   'Status',   'manage_options', 'koto-seo-status', 'koto_page_status'    );
    add_submenu_page( 'koto-seo', 'Settings', 'Settings', 'manage_options', 'koto-seo-setup',  'koto_page_setup'     );
} );

// ── Shared styles ─────────────────────────────────────────────────────────────
function koto_styles() { ?>
<style>
  .koto-wrap { max-width:640px; }
  .koto-card { background:#fff; border:1px solid #e0e0e0; border-radius:10px; padding:24px; margin-bottom:20px; }
  .koto-logo { display:flex; align-items:center; gap:12px; margin-bottom:20px; }
  .koto-logo-icon { width:40px; height:40px; background:#ea2729; border-radius:8px; display:flex; align-items:center; justify-content:center; }
  .koto-logo-text h2 { margin:0; font-size:18px; } .koto-logo-text p { margin:0; color:#666; font-size:13px; }
  .koto-badge-ok  { background:#f0fdf4; border:1px solid #bbf7d0; border-radius:8px; padding:12px 16px; color:#166534; }
  .koto-badge-warn{ background:#fef3c7; border:1px solid #fde68a; border-radius:8px; padding:12px 16px; color:#92400e; }
  .koto-badge-err { background:#fef2f2; border:1px solid #fecaca; border-radius:8px; padding:12px 16px; color:#991b1b; }
  .koto-grid2 { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  .koto-stat  { background:#f9fafb; border:1px solid #e5e7eb; border-radius:8px; padding:14px 16px; }
  .koto-stat strong { display:block; font-size:22px; color:#111; }
  .koto-stat span   { font-size:12px; color:#6b7280; }
  .koto-btn-r { background:#ea2729; color:#fff; border:none; border-radius:6px; padding:8px 18px; font-weight:700; cursor:pointer; }
  .koto-powered { text-align:center; padding:16px; font-size:12px; color:#9ca3af; margin-top:8px; }
  .koto-powered a { color:#9ca3af; font-weight:700; text-decoration:none; }
</style>
<?php }

function koto_logo_html( $title = '', $sub = '' ) {
    $title = $title ?: 'Koto SEO Plugin';
    $sub   = $sub   ?: 'v' . KOTO_VERSION . ' &nbsp;·&nbsp; <a href="https://hellokoto.com" target="_blank">hellokoto.com</a>';
    return '<div class="koto-logo">
      <div class="koto-logo-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
        </svg>
      </div>
      <div class="koto-logo-text"><h2>' . esc_html($title) . '</h2><p>' . $sub . '</p></div>
    </div>';
}

// ── Dashboard page ────────────────────────────────────────────────────────────
function koto_page_dashboard() {
    koto_styles();
    $connected  = (bool) get_option('koto_api_key');
    $agency_url = get_option('koto_agency_url', 'https://hellokoto.com');
    $client_id  = get_option('koto_client_id', '');
    ?>
    <div class="wrap koto-wrap">
      <?php echo koto_logo_html(); ?>

      <?php if ( $connected ): ?>
        <div class="koto-badge-ok" style="margin-bottom:16px;">
          ✓ <strong>Connected to Koto Agency Platform</strong><br>
          <span style="font-size:13px;color:#166534;"><?php echo esc_html($agency_url); ?></span>
        </div>
      <?php else: ?>
        <div class="koto-badge-warn" style="margin-bottom:16px;">
          <strong>Not connected.</strong> Go to <a href="<?php echo admin_url('admin.php?page=koto-seo-setup'); ?>">Settings</a> to paste your API key from the Koto dashboard.
        </div>
      <?php endif; ?>

      <div class="koto-card">
        <h3 style="margin-top:0;">Quick Actions</h3>
        <div class="koto-grid2">
          <?php if ( $connected ): ?>
            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=koto-seo&action=sync'), 'koto_sync'); ?>" class="button button-primary">🔄 Sync Now</a>
            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=koto-seo&action=ping'), 'koto_ping'); ?>" class="button">📡 Ping Search Engines</a>
            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=koto-seo&action=sitemap'), 'koto_sitemap'); ?>" class="button">🗺️ Rebuild Sitemap</a>
          <?php endif; ?>
          <a href="<?php echo admin_url('admin.php?page=koto-seo-status'); ?>" class="button">📊 View Status</a>
          <a href="<?php echo admin_url('admin.php?page=koto-seo-setup'); ?>" class="button">⚙️ Settings</a>
          <?php if ( $client_id ): ?>
          <a href="<?php echo esc_url($agency_url . '/clients/' . $client_id); ?>" target="_blank" class="button">🚀 Open Koto Dashboard ↗</a>
          <?php endif; ?>
        </div>

        <?php
        // Handle quick actions
        if ( isset($_GET['action']) && current_user_can('manage_options') ) {
            $action = sanitize_text_field($_GET['action']);
            if ( $action === 'sync' && wp_verify_nonce($_GET['_wpnonce']??'','koto_sync') ) {
                $r = koto_do_sync();
                echo $r ? '<div class="notice notice-success inline"><p>✓ Sync complete.</p></div>' : '<div class="notice notice-error inline"><p>Sync failed — check connection.</p></div>';
            }
            if ( $action === 'ping' && wp_verify_nonce($_GET['_wpnonce']??'','koto_ping') ) {
                koto_ping_engines();
                echo '<div class="notice notice-success inline"><p>✓ Search engines pinged.</p></div>';
            }
            if ( $action === 'sitemap' && wp_verify_nonce($_GET['_wpnonce']??'','koto_sitemap') ) {
                koto_rebuild_sitemap();
                echo '<div class="notice notice-success inline"><p>✓ Sitemap rebuild triggered.</p></div>';
            }
        }
        ?>
      </div>

      <div class="koto-powered">Powered by <a href="https://hellokoto.com" target="_blank">koto</a> &nbsp;·&nbsp; <a href="https://hellokoto.com" target="_blank">hellokoto.com</a></div>
    </div>
    <?php
}

// ── Status page ───────────────────────────────────────────────────────────────
function koto_page_status() {
    global $wpdb;
    koto_styles();
    $api_key    = get_option('koto_api_key');
    $agency_url = get_option('koto_agency_url', '—');
    $last_sync  = get_option('koto_last_sync', 'Never');
    $post_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status='publish' AND post_type='post'");
    $page_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status='publish' AND post_type='page'");
    $yoast      = defined('WPSEO_VERSION');
    $rankmath   = defined('RANK_MATH_VERSION');
    ?>
    <div class="wrap koto-wrap">
      <?php echo koto_logo_html('Koto SEO — Status'); ?>
      <div class="koto-card">
        <div class="koto-grid2" style="margin-bottom:16px;">
          <div class="koto-stat"><strong><?php echo $post_count; ?></strong><span>Published Posts</span></div>
          <div class="koto-stat"><strong><?php echo $page_count; ?></strong><span>Published Pages</span></div>
          <div class="koto-stat"><strong><?php echo esc_html(get_bloginfo('version')); ?></strong><span>WordPress Version</span></div>
          <div class="koto-stat"><strong><?php echo PHP_VERSION; ?></strong><span>PHP Version</span></div>
        </div>
        <table class="widefat" style="border:none;">
          <tr><th>Connection</th><td><?php echo $api_key ? '<span style="color:#16a34a;">✓ Connected</span>' : '<span style="color:#dc2626;">Not connected</span>'; ?></td></tr>
          <tr><th>Agency URL</th><td><?php echo esc_html($agency_url); ?></td></tr>
          <tr><th>Site URL</th><td><?php echo esc_html(get_site_url()); ?></td></tr>
          <tr><th>Site Name</th><td><?php echo esc_html(get_bloginfo('name')); ?></td></tr>
          <tr><th>Last Sync</th><td><?php echo esc_html($last_sync); ?></td></tr>
          <tr><th>SEO Plugin</th><td><?php echo $yoast ? 'Yoast SEO ' . WPSEO_VERSION : ($rankmath ? 'Rank Math ' . RANK_MATH_VERSION : 'None detected'); ?></td></tr>
          <tr><th>REST API Namespace</th><td><code>/wp-json/koto/v1/</code></td></tr>
          <tr><th>Plugin Version</th><td><?php echo KOTO_VERSION; ?></td></tr>
        </table>
      </div>
      <div class="koto-powered">Powered by <a href="https://hellokoto.com" target="_blank">koto</a> &nbsp;·&nbsp; <a href="https://hellokoto.com" target="_blank">hellokoto.com</a></div>
    </div>
    <?php
}

// ── Settings page ─────────────────────────────────────────────────────────────
function koto_page_setup() {
    koto_styles();
    if ( isset($_POST['koto_save']) && check_admin_referer('koto_setup') ) {
        update_option( 'koto_api_key',    sanitize_text_field($_POST['api_key']) );
        update_option( 'koto_agency_url', esc_url_raw($_POST['agency_url']) );
        update_option( 'koto_client_id',  sanitize_text_field($_POST['client_id']) );
        // Auto-register with Koto
        $reg = koto_register_site();
        if ( is_wp_error($reg) ) {
            echo '<div class="notice notice-warning"><p>Settings saved. Registration: ' . esc_html($reg->get_error_message()) . '</p></div>';
        } else {
            if ( ! empty($reg['site_id']) ) update_option('koto_site_id', $reg['site_id']);
            echo '<div class="notice notice-success"><p>✓ Connected to Koto successfully!</p></div>';
        }
    }
    $api_key    = get_option('koto_api_key', '');
    $agency_url = get_option('koto_agency_url', 'https://hellokoto.com');
    $client_id  = get_option('koto_client_id', '');
    ?>
    <div class="wrap koto-wrap">
      <?php echo koto_logo_html('Koto SEO — Settings'); ?>
      <div class="koto-card">
        <p style="color:#374151;margin-bottom:20px;">
          Copy your API key from <strong>Koto Dashboard → WordPress Sites → Connect New Site</strong>, then paste it below.
        </p>
        <form method="post">
          <?php wp_nonce_field('koto_setup'); ?>
          <table class="form-table">
            <tr>
              <th><label for="agency_url">Koto Agency URL</label></th>
              <td>
                <input type="url" id="agency_url" name="agency_url" value="<?php echo esc_attr($agency_url); ?>" class="regular-text" placeholder="https://hellokoto.com" />
                <p class="description">Your Koto platform URL — usually https://hellokoto.com</p>
              </td>
            </tr>
            <tr>
              <th><label for="api_key">API Key</label></th>
              <td>
                <input type="password" id="api_key" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text" placeholder="koto_live_xxxxxxxxxxxxxxxx" />
                <p class="description">Found in Koto → Settings → API Keys</p>
              </td>
            </tr>
            <tr>
              <th><label for="client_id">Client ID <small>(optional)</small></label></th>
              <td>
                <input type="text" id="client_id" name="client_id" value="<?php echo esc_attr($client_id); ?>" class="regular-text" placeholder="UUID from Koto client record" />
                <p class="description">Links this site to a specific client in your Koto account</p>
              </td>
            </tr>
          </table>
          <p class="submit">
            <button type="submit" name="koto_save" class="button button-primary koto-btn-r">Save & Connect</button>
          </p>
        </form>
      </div>

      <div class="koto-card">
        <h3 style="margin-top:0;">API Endpoints (for reference)</h3>
        <p style="color:#6b7280;font-size:13px;">These are the endpoints your Koto dashboard calls on this WordPress site:</p>
        <table class="widefat" style="font-size:13px;">
          <thead><tr><th>Endpoint</th><th>Method</th><th>Purpose</th></tr></thead>
          <tbody>
            <tr><td><code>GET /agency/test</code></td><td>GET</td><td>Connection test + full site info</td></tr>
            <tr><td><code>GET /pages</code></td><td>GET</td><td>List all published pages with SEO data</td></tr>
            <tr><td><code>POST /generate/batch</code></td><td>POST</td><td>Generate city/location landing pages</td></tr>
            <tr><td><code>GET /gsc/overview</code></td><td>GET</td><td>Google Search Console data overview</td></tr>
            <tr><td><code>POST /blog/generate</code></td><td>POST</td><td>AI blog post generation</td></tr>
            <tr><td><code>POST /automation/run-now</code></td><td>POST</td><td>Trigger SEO automation run</td></tr>
            <tr><td><code>POST /sitemap/rebuild</code></td><td>POST</td><td>Rebuild and ping sitemap</td></tr>
          </tbody>
        </table>
        <p style="font-size:12px;color:#9ca3af;margin-top:8px;">All requests authenticated via <code>Authorization: Bearer {api_key}</code> or <code>X-KOTO-Key</code> header.</p>
      </div>
      <div class="koto-powered">Powered by <a href="https://hellokoto.com" target="_blank">koto</a> &nbsp;·&nbsp; <a href="https://hellokoto.com" target="_blank">hellokoto.com</a></div>
    </div>
    <?php
}

// ── Settings registration ─────────────────────────────────────────────────────
add_action( 'admin_init', function() {
    register_setting('koto_settings', 'koto_api_key');
    register_setting('koto_settings', 'koto_agency_url');
    register_setting('koto_settings', 'koto_client_id');
});

// ── Auth middleware ───────────────────────────────────────────────────────────
function koto_auth( WP_REST_Request $request ): bool|WP_Error {
    $stored = get_option('koto_api_key');
    if ( ! $stored ) return new WP_Error('not_configured', 'Koto plugin not configured', ['status'=>401]);
    $provided = $request->get_header('Authorization') ?: $request->get_header('X-KOTO-Key') ?: $request->get_header('X-Koto-Key');
    $provided = trim(str_replace(['Bearer ','bearer '], '', $provided ?? ''));
    return hash_equals($stored, $provided)
        ? true
        : new WP_Error('unauthorized', 'Invalid API key', ['status'=>401]);
}

// ── REST API ──────────────────────────────────────────────────────────────────
add_action( 'rest_api_init', function() {
    $ns = KOTO_NS;

    // GET /agency/test — connection test + full site info (used by WP Control Center)
    register_rest_route($ns, '/agency/test', [
        'methods'             => 'GET',
        'callback'            => 'koto_rest_agency_test',
        'permission_callback' => 'koto_auth',
    ]);

    // GET /pages — list published pages with SEO metadata
    register_rest_route($ns, '/pages', [
        'methods'             => 'GET',
        'callback'            => 'koto_rest_pages',
        'permission_callback' => 'koto_auth',
    ]);

    // POST /generate/batch — create city/location landing pages
    register_rest_route($ns, '/generate/batch', [
        'methods'             => 'POST',
        'callback'            => 'koto_rest_generate_batch',
        'permission_callback' => 'koto_auth',
    ]);

    // GET /gsc/overview — GSC data summary
    register_rest_route($ns, '/gsc/overview', [
        'methods'             => 'GET',
        'callback'            => 'koto_rest_gsc_overview',
        'permission_callback' => 'koto_auth',
    ]);

    // POST /blog/generate — create an AI blog post
    register_rest_route($ns, '/blog/generate', [
        'methods'             => 'POST',
        'callback'            => 'koto_rest_blog_generate',
        'permission_callback' => 'koto_auth',
    ]);

    // POST /automation/run-now — trigger automation sequence
    register_rest_route($ns, '/automation/run-now', [
        'methods'             => 'POST',
        'callback'            => 'koto_rest_automation_run',
        'permission_callback' => 'koto_auth',
    ]);

    // POST /sitemap/rebuild — rebuild sitemap and ping engines
    register_rest_route($ns, '/sitemap/rebuild', [
        'methods'             => 'POST',
        'callback'            => 'koto_rest_sitemap_rebuild',
        'permission_callback' => 'koto_auth',
    ]);

    // GET /rankings — local ranking snapshot data
    register_rest_route($ns, '/rankings', [
        'methods'             => 'GET',
        'callback'            => 'koto_rest_rankings',
        'permission_callback' => 'koto_auth',
    ]);
});

// ── REST Callbacks ────────────────────────────────────────────────────────────

function koto_rest_agency_test(): WP_REST_Response {
    global $wpdb;
    $post_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status='publish' AND post_type='post'");
    $page_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status='publish' AND post_type='page'");
    $yoast      = defined('WPSEO_VERSION') ? WPSEO_VERSION : null;
    $rankmath   = defined('RANK_MATH_VERSION') ? RANK_MATH_VERSION : null;

    // Check GSC integration
    $gsc_property = get_option('wpseo_ms', [])['siteurl'] ?? get_option('gsc_property_url', null);

    update_option('koto_last_sync', current_time('mysql'));
    return rest_ensure_response([
        'status'          => 'connected',
        'site_url'        => get_site_url(),
        'site_name'       => get_bloginfo('name'),
        'tagline'         => get_bloginfo('description'),
        'wp_version'      => get_bloginfo('version'),
        'php_version'     => PHP_VERSION,
        'plugin_version'  => KOTO_VERSION,
        'posts_count'     => $post_count,
        'pages_count'     => $page_count,
        'yoast_version'   => $yoast,
        'rankmath_version'=> $rankmath,
        'seo_plugin'      => $yoast ? 'yoast' : ($rankmath ? 'rankmath' : 'none'),
        'gsc_connected'   => ! empty($gsc_property),
        'client_id'       => get_option('koto_client_id', null),
        'last_sync'       => get_option('koto_last_sync'),
        'active_plugins'  => array_values(array_map('dirname', get_option('active_plugins', []))),
        'theme'           => get_template(),
        'admin_email'     => get_option('admin_email'),
        'timezone'        => get_option('timezone_string') ?: get_option('gmt_offset'),
    ]);
}

function koto_rest_pages( WP_REST_Request $request ): WP_REST_Response {
    global $wpdb;
    $pages = get_posts([
        'post_type'      => ['post', 'page'],
        'post_status'    => 'publish',
        'posts_per_page' => 200,
        'orderby'        => 'modified',
        'order'          => 'DESC',
    ]);

    $result = [];
    foreach ( $pages as $p ) {
        $yoast_title   = get_post_meta($p->ID, '_yoast_wpseo_title', true);
        $yoast_desc    = get_post_meta($p->ID, '_yoast_wpseo_metadesc', true);
        $rm_title      = get_post_meta($p->ID, 'rank_math_title', true);
        $rm_desc       = get_post_meta($p->ID, 'rank_math_description', true);
        $focus_kw      = get_post_meta($p->ID, '_yoast_wpseo_focuskw', true) ?: get_post_meta($p->ID, 'rank_math_focus_keyword', true);

        $result[] = [
            'id'           => $p->ID,
            'title'        => $p->post_title,
            'url'          => get_permalink($p->ID),
            'slug'         => $p->post_name,
            'type'         => $p->post_type,
            'modified'     => $p->post_modified,
            'word_count'   => str_word_count(wp_strip_all_tags($p->post_content)),
            'seo_title'    => $yoast_title ?: $rm_title ?: '',
            'meta_desc'    => $yoast_desc  ?: $rm_desc  ?: '',
            'focus_kw'     => $focus_kw    ?: '',
            'has_seo_meta' => ! empty($yoast_desc) || ! empty($rm_desc),
        ];
    }
    return rest_ensure_response([ 'pages' => $result, 'total' => count($result), 'retrieved_at' => current_time('c') ]);
}

function koto_rest_generate_batch( WP_REST_Request $request ): WP_REST_Response {
    $params   = $request->get_json_params();
    $pages    = $params['pages']    ?? [];
    $template = $params['template'] ?? '';  // content template with %s for city
    $schema   = $params['schema']   ?? 'LocalBusiness';
    $aeo      = $params['aeo']      ?? false;
    $status   = $params['status']   ?? 'draft';

    if ( empty($pages) ) {
        return new WP_REST_Response([ 'error' => 'No pages provided' ], 400);
    }

    $created = [];
    $errors  = [];

    foreach ( $pages as $page ) {
        $city    = sanitize_text_field($page['city'] ?? '');
        $state   = sanitize_text_field($page['state'] ?? '');
        $keyword = sanitize_text_field($page['keyword'] ?? '');
        $content = str_replace(['%city%','%state%','%keyword%','%s'], [$city,$state,$keyword,$city], $template);

        if ( $aeo ) {
            $content .= "\n\n<!-- AEO Schema -->\n<script type=\"application/ld+json\">" . wp_json_encode([
                '@context' => 'https://schema.org',
                '@type'    => $schema,
                'name'     => get_bloginfo('name'),
                'areaServed' => [ '@type' => 'City', 'name' => $city ],
            ]) . "</script>";
        }

        $title   = str_replace(['%city%','%state%','%keyword%','%s'], [$city,$state,$keyword,$city], $keyword ?: "$city $state Services");
        $post_id = wp_insert_post([
            'post_title'   => $title,
            'post_content' => $content,
            'post_status'  => $status,
            'post_type'    => 'page',
            'post_name'    => sanitize_title("$keyword-$city-$state"),
        ], true);

        if ( is_wp_error($post_id) ) {
            $errors[] = [ 'city' => $city, 'error' => $post_id->get_error_message() ];
        } else {
            $created[] = [ 'id' => $post_id, 'city' => $city, 'url' => get_permalink($post_id), 'title' => $title ];
        }
    }

    // Normalize to format expected by Koto WP Control Center
    $pages = array_map(fn($p) => [
        'post_id'   => $p['id'],
        'title'     => $p['title'],
        'keyword'   => str_replace(['%city%','%state%','%keyword%','%s'], [$p['city'],$p['city'],$p['city'],$p['city']], $keyword ?? ''),
        'location'  => $p['city'],
        'url'       => $p['url'],
        'slug'      => sanitize_title($p['title']),
        'status'    => $status,
        'word_count'=> str_word_count(strip_tags($template)),
        'seo_score' => null,
    ], $created);

    update_option('koto_last_sync', current_time('mysql'));
    return rest_ensure_response([
        'success'       => count($errors) === 0,
        'pages'         => $pages,
        'created'       => $created,
        'errors'        => $errors,
        'created_count' => count($created),
        'error_count'   => count($errors),
        'generated'     => count($created),
        'generated_at'  => current_time('c'),
    ]);
}

function koto_rest_gsc_overview(): WP_REST_Response {
    // Returns GSC data if available via Yoast or Site Kit
    $gsc_data = [
        'available'   => false,
        'note'        => 'Connect Google Search Console via Yoast SEO, Rank Math, or Google Site Kit to see data here.',
        'retrieved_at'=> current_time('c'),
    ];

    // Check if Rank Math has GSC
    if ( class_exists('RankMath\\Google\\Api') ) {
        $gsc_data['available'] = true;
        $gsc_data['source']    = 'rankmath';
    }

    // Check if Yoast has GSC configured
    if ( defined('WPSEO_VERSION') && get_option('wpseo_ms') ) {
        $gsc_data['available'] = true;
        $gsc_data['source']    = 'yoast';
    }

    return rest_ensure_response($gsc_data);
}

function koto_rest_blog_generate( WP_REST_Request $request ): WP_REST_Response {
    $params  = $request->get_json_params();
    $title   = sanitize_text_field($params['title']   ?? '');
    $content = wp_kses_post($params['content']        ?? '');
    $meta    = sanitize_text_field($params['meta_description'] ?? '');
    $keyword = sanitize_text_field($params['focus_keyword']    ?? '');
    $status  = sanitize_text_field($params['status']  ?? 'draft');
    $tags    = array_map('sanitize_text_field', $params['tags'] ?? []);

    if ( empty($title) || empty($content) ) {
        return new WP_REST_Response([ 'error' => 'title and content are required' ], 400);
    }

    $tag_ids = [];
    foreach ( $tags as $tag ) {
        $term = wp_insert_term($tag, 'post_tag');
        $tag_ids[] = is_wp_error($term) ? $term->error_data['term_exists'] : $term['term_id'];
    }

    $post_id = wp_insert_post([
        'post_title'   => $title,
        'post_content' => $content,
        'post_status'  => $status,
        'post_type'    => 'post',
        'tags_input'   => $tag_ids,
        'post_name'    => sanitize_title($title),
    ], true);

    if ( is_wp_error($post_id) ) {
        return new WP_REST_Response([ 'error' => $post_id->get_error_message() ], 500);
    }

    // Set SEO meta if Yoast or Rank Math is active
    if ( $meta ) {
        if ( defined('WPSEO_VERSION') ) update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta);
        if ( defined('RANK_MATH_VERSION') ) update_post_meta($post_id, 'rank_math_description', $meta);
    }
    if ( $keyword ) {
        if ( defined('WPSEO_VERSION') ) update_post_meta($post_id, '_yoast_wpseo_focuskw', $keyword);
        if ( defined('RANK_MATH_VERSION') ) update_post_meta($post_id, 'rank_math_focus_keyword', $keyword);
    }

    update_option('koto_last_sync', current_time('mysql'));
    return rest_ensure_response([
        'success'      => true,
        'post_id'      => $post_id,
        'url'          => get_permalink($post_id),
        'title'        => $title,
        'status'       => $status,
        'generated_at' => current_time('c'),
    ]);
}

function koto_rest_automation_run( WP_REST_Request $request ): WP_REST_Response {
    $params    = $request->get_json_params();
    $run_types = $params['run_types'] ?? ['sitemap', 'ping'];
    $results   = [];

    if ( in_array('sitemap', $run_types) ) {
        $results['sitemap'] = koto_rebuild_sitemap();
    }
    if ( in_array('ping', $run_types) ) {
        $results['ping'] = koto_ping_engines();
    }

    update_option('koto_last_automation', current_time('mysql'));
    return rest_ensure_response([
        'success'    => true,
        'results'    => $results,
        'ran_at'     => current_time('c'),
    ]);
}

function koto_rest_sitemap_rebuild(): WP_REST_Response {
    $result = koto_rebuild_sitemap();
    return rest_ensure_response($result);
}

function koto_rest_rankings(): WP_REST_Response {
    // Placeholder — rankings are tracked by Koto platform, not the plugin
    return rest_ensure_response([
        'note'         => 'Rankings are tracked by the Koto platform. Connect GSC for keyword data.',
        'retrieved_at' => current_time('c'),
    ]);
}

// ── Helper functions ──────────────────────────────────────────────────────────

function koto_rebuild_sitemap(): array {
    $pinged = false;
    if ( function_exists('wpseo_get_value') || defined('WPSEO_VERSION') ) {
        do_action('wpseo_rebuild_sitemap', true);
        $pinged = true;
    }
    if ( defined('RANK_MATH_VERSION') && class_exists('RankMath\Sitemap\Sitemap') ) {
        do_action('rank_math/sitemap/hit_index');
        $pinged = true;
    }
    $ping = koto_ping_engines();
    return [ 'success' => true, 'method' => $pinged ? 'seo_plugin' : 'native', 'ping' => $ping, 'time' => current_time('c') ];
}

function koto_ping_engines(): array {
    $sitemap = get_site_url() . '/sitemap.xml';
    $results = [];
    foreach ( ['google' => 'https://www.google.com/ping?sitemap=', 'bing' => 'https://www.bing.com/ping?sitemap='] as $name => $base ) {
        $r = wp_remote_get($base . urlencode($sitemap), ['timeout'=>8]);
        $results[$name] = is_wp_error($r) ? 'error' : wp_remote_retrieve_response_code($r);
    }
    return [ 'success' => true, 'results' => $results, 'sitemap' => $sitemap ];
}

function koto_do_sync(): bool {
    $api_key    = get_option('koto_api_key');
    $agency_url = get_option('koto_agency_url', 'https://hellokoto.com');
    if ( ! $api_key ) return false;
    $r = wp_remote_post(trailingslashit($agency_url) . 'api/seo/wp-ping', [
        'headers' => ['Content-Type'=>'application/json','X-Koto-Key'=>$api_key,'Authorization'=>"Bearer $api_key"],
        'body'    => wp_json_encode(['event'=>'manual_sync','site_url'=>get_site_url(),'time'=>current_time('c')]),
        'timeout' => 10,
    ]);
    $ok = ! is_wp_error($r) && wp_remote_retrieve_response_code($r) < 400;
    if ( $ok ) update_option('koto_last_sync', current_time('mysql'));
    return $ok;
}

function koto_register_site(): array|WP_Error {
    $api_key    = get_option('koto_api_key');
    $agency_url = get_option('koto_agency_url', 'https://hellokoto.com');
    $r = wp_remote_post(trailingslashit($agency_url) . 'api/seo/wp-register', [
        'headers' => ['Content-Type'=>'application/json','X-Koto-Key'=>$api_key,'Authorization'=>"Bearer $api_key"],
        'body'    => wp_json_encode([
            'site_url'    => get_site_url(),
            'site_name'   => get_bloginfo('name'),
            'wp_version'  => get_bloginfo('version'),
            'php_version' => PHP_VERSION,
            'client_id'   => get_option('koto_client_id',''),
            'plugin_version' => KOTO_VERSION,
        ]),
        'timeout' => 15,
    ]);
    if ( is_wp_error($r) ) return $r;
    $body = json_decode(wp_remote_retrieve_body($r), true);
    return $body ?: new WP_Error('parse_error', 'Invalid response from Koto');
}

// ── Auto-ping on post publish ─────────────────────────────────────────────────
add_action('publish_post', function( $post_id ) {
    $api_key    = get_option('koto_api_key');
    $agency_url = get_option('koto_agency_url');
    if ( ! $api_key || ! $agency_url ) return;
    wp_remote_post(trailingslashit($agency_url) . 'api/seo/wp-ping', [
        'headers' => ['Content-Type'=>'application/json','X-Koto-Key'=>$api_key,'Authorization'=>"Bearer $api_key"],
        'body'    => wp_json_encode(['event'=>'post_published','post_id'=>$post_id,'site_url'=>get_site_url()]),
        'timeout' => 5,
        'blocking'=> false,
    ]);
}, 10, 1);

// ── Also keep hlseo/v1 namespace for backward compatibility ───────────────────
add_action( 'rest_api_init', function() {
    $legacy = 'hlseo/v1';
    register_rest_route($legacy, '/site/info',  ['methods'=>'GET',  'callback'=>'koto_rest_agency_test', 'permission_callback'=>'koto_auth']);
    register_rest_route($legacy, '/stats',       ['methods'=>'GET',  'callback'=>'koto_rest_agency_test', 'permission_callback'=>'koto_auth']);
    register_rest_route($legacy, '/agency/test', ['methods'=>'GET',  'callback'=>'koto_rest_agency_test', 'permission_callback'=>'koto_auth']);
    register_rest_route($legacy, '/sitemap/rebuild', ['methods'=>'POST','callback'=>'koto_rest_sitemap_rebuild','permission_callback'=>'koto_auth']);
});

// ── Locations endpoint (serves city/state data from Koto geo files) ───────────
add_action( 'rest_api_init', function() {
    // GET /koto/v1/locations/cities?state=FL — returns city list from Koto geo data
    register_rest_route( KOTO_NS, '/locations/cities', [
        'methods'             => 'GET',
        'callback'            => 'koto_rest_locations_cities',
        'permission_callback' => 'koto_auth',
    ]);
    register_rest_route( KOTO_NS, '/locations/states', [
        'methods'             => 'GET',
        'callback'            => 'koto_rest_locations_states',
        'permission_callback' => 'koto_auth',
    ]);
    // Legacy hlseo/v1
    register_rest_route( 'hlseo/v1', '/locations/cities', [
        'methods'             => 'GET',
        'callback'            => 'koto_rest_locations_cities',
        'permission_callback' => 'koto_auth',
    ]);
});

function koto_rest_locations_states(): WP_REST_Response {
    $states = [
        'AL'=>'Alabama','AK'=>'Alaska','AZ'=>'Arizona','AR'=>'Arkansas','CA'=>'California',
        'CO'=>'Colorado','CT'=>'Connecticut','DE'=>'Delaware','FL'=>'Florida','GA'=>'Georgia',
        'HI'=>'Hawaii','ID'=>'Idaho','IL'=>'Illinois','IN'=>'Indiana','IA'=>'Iowa',
        'KS'=>'Kansas','KY'=>'Kentucky','LA'=>'Louisiana','ME'=>'Maine','MD'=>'Maryland',
        'MA'=>'Massachusetts','MI'=>'Michigan','MN'=>'Minnesota','MS'=>'Mississippi','MO'=>'Missouri',
        'MT'=>'Montana','NE'=>'Nebraska','NV'=>'Nevada','NH'=>'New Hampshire','NJ'=>'New Jersey',
        'NM'=>'New Mexico','NY'=>'New York','NC'=>'North Carolina','ND'=>'North Dakota','OH'=>'Ohio',
        'OK'=>'Oklahoma','OR'=>'Oregon','PA'=>'Pennsylvania','RI'=>'Rhode Island','SC'=>'South Carolina',
        'SD'=>'South Dakota','TN'=>'Tennessee','TX'=>'Texas','UT'=>'Utah','VT'=>'Vermont',
        'VA'=>'Virginia','WA'=>'Washington','WV'=>'West Virginia','WI'=>'Wisconsin','WY'=>'Wyoming',
        'DC'=>'Washington D.C.',
    ];
    return rest_ensure_response([ 'states' => $states ]);
}

function koto_rest_locations_cities( WP_REST_Request $request ): WP_REST_Response {
    $state  = strtolower( $request->get_param('state') ?? '' );
    $county = $request->get_param('county') ?? '';

    if ( ! $state ) {
        return new WP_REST_Response([ 'error' => 'state parameter required' ], 400);
    }

    // Try to fetch geo data from Koto platform
    $agency_url = get_option('koto_agency_url', 'https://hellokoto.com');
    $geo_url    = trailingslashit($agency_url) . "geo/{$state}.json";
    $response   = wp_remote_get($geo_url, [ 'timeout' => 8 ]);

    if ( ! is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200 ) {
        $body = json_decode( wp_remote_retrieve_body($response), true );
        $cities = $body['cities'] ?? [];

        // Filter by county if specified
        if ( $county ) {
            $cities = array_values( array_filter($cities, fn($c) => strcasecmp($c['c'] ?? '', $county) === 0) );
        }

        // Normalize to expected format
        $normalized = array_map(fn($c) => [
            'id'         => sanitize_title( ($c['n'] ?? '') . '-' . strtolower($state) ),
            'city'       => $c['n'] ?? '',
            'state'      => strtoupper($state),
            'county'     => $c['c'] ?? '',
            'zip'        => $c['z'][0] ?? '',
            'lat'        => $c['lat'] ?? null,
            'lng'        => $c['lng'] ?? null,
            'population' => null,
        ], $cities);

        return rest_ensure_response([
            'locations' => $normalized,
            'cities'    => $normalized,
            'state'     => strtoupper($state),
            'total'     => count($normalized),
        ]);
    }

    // Fallback: return empty with helpful message
    return rest_ensure_response([
        'locations' => [],
        'cities'    => [],
        'state'     => strtoupper($state),
        'total'     => 0,
        'note'      => 'Could not fetch geo data from Koto. Verify agency URL is set in plugin settings.',
    ]);
}
