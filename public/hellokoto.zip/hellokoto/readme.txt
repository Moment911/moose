=== HelloKoto ===
Contributors: koto
Tags: marketing, seo, ai, voice, agency
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 3.0.0
License: GPL-2.0+

Connect your WordPress site to the HelloKoto AI Marketing Platform. Enables AI front desk, rank tracking, page generation, GSC sync, sitemap management, review campaigns, and automated SEO reporting.

== Description ==

HelloKoto is the AI-powered marketing platform for agencies. This plugin connects your WordPress site to your agency's Koto dashboard for:

* **AI Voice Front Desk** — Virtual receptionist that answers calls, books appointments, transfers to staff
* **SEO & Content** — AI-generated pages, rank tracking, sitemap management, monthly reports
* **Review Management** — Automated review campaigns and monitoring
* **Scout Intelligence** — AI lead research and competitive analysis
* **Page Builder** — AI-powered landing pages published directly to WordPress

== Installation ==

1. Upload the `hellokoto` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu
3. Go to HelloKoto → Settings
4. Enter your Agency URL (usually https://hellokoto.com)
5. Enter your API Key from the Koto dashboard
6. Save — the plugin will auto-register with your agency

== Changelog ==

= 3.0.0 =
* Rebranded from "Koto SEO" to "HelloKoto"
* Added remote-loaded welcome page
* Updated brand colors and design
* All existing functionality preserved
